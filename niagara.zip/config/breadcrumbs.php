<?php

return [

	'view' => 'breadcrumbs::bootstrap3',

];
