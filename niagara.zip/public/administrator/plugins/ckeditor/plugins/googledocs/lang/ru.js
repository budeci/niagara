CKEDITOR.plugins.setLang( 'googledocs', 'ru', {
  button:         'Документ',
  title:          'Свойства документа',
  settingsTab:    'Настройки',
  selectDocument: 'Выбирите документ из списка',
  url:            'Ссылка на документ',
  alertUrl:       'Пожалуйста, введите ссылку на документ.',
  alertWidth:     'Ширина должна быть задана числом.',
  alertHeight:    'Высота должна быть задана числом.',
  uploadTab:      'Загрузить',
  btnUpload:      'Загрузить на сервер'
});