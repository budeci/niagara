<?php

namespace App\Libraries\Presenterable\Presenters;

class StrategyPresenter extends Presenter
{
    public function strategyContent()
    {
        return;
    }
}