<?php

namespace App\Libraries;

use Illuminate\Database\Eloquent\Model;

class TranslatableModel extends Model
{
    /**
     * @var bool
     */
    public $timestamps = false;

    public function parent()
    {
//        return 
    }
}