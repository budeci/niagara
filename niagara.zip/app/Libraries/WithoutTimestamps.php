<?php

namespace App\Libraries;

trait WithoutTimestamps
{
    public $timestamps = false;
}